#include "shared_mem.h"

int main() {
    // Create shared memory
    int shm_fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    ftruncate(shm_fd, sizeof(SharedMemory));
    SharedMemory* shm_ptr = (SharedMemory*) mmap(0, sizeof(SharedMemory),
                                                 PROT_WRITE | PROT_READ,
                                                 MAP_SHARED, shm_fd, 0);
    if (shm_ptr == MAP_FAILED) {
        cerr << "Failed to map shared memory!" << endl;
        return 1;
    }

    // Create semaphores
    sem_t* sem_write = sem_open(SEM_WRITE, O_CREAT, 0666, 0);
    sem_t* sem_read = sem_open(SEM_READ, O_CREAT, 0666, 1);

    if (sem_write == SEM_FAILED || sem_read == SEM_FAILED) {
        cerr << "Failed to open semaphores!" << endl;
        return 1;
    }

    // Produce 5 messages
    for (int i = 0; i < 5; ++i) {
        sem_wait(sem_read); // Wait until empty is available

        string message = "Message " + to_string(i+1);
        strcpy(shm_ptr->message, message.c_str());
        cout << "[Producer] Sent: " << message << endl;

        sem_post(sem_write); // Signal that the message is ready
        sleep(1);
    }

    // Cleanup
    sem_close(sem_write);
    sem_close(sem_read);
    munmap(shm_ptr, sizeof(SharedMemory));
    shm_unlink(SHM_NAME);

    return 0;
}
