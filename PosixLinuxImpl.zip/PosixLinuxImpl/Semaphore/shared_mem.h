#ifndef SHARED_MEMORY_H
#define SHARED_MEMORY_H

#include <fcntl.h>
#include <sys/mman.h>
#include <semaphore.h>
#include <unistd.h>
#include <cstring>
#include <iostream>
#include "shared_mem.h"

using namespace std;

#define SHM_NAME "/my_shm"       // Shared memory object
#define SEM_WRITE "/sem_write"     // Semaphore for full
#define SEM_READ "/sem_read"   // Semaphore for empty
#define MAX_MSG_SIZE 1024

struct SharedMemory {
    char message[MAX_MSG_SIZE];
};

#endif
