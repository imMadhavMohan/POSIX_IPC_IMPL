#include "shared_mem.h"

int main() {
    // Open existing shared memory
    int shm_fd = shm_open(SHM_NAME, O_RDWR, 0666);
    if (shm_fd == -1) {
        cerr << "Failed to open shared memory!" << endl;
        return 1;
    }

    SharedMemory* shm_ptr = (SharedMemory*) mmap(0, sizeof(SharedMemory),
                                                 PROT_WRITE | PROT_READ,
                                                 MAP_SHARED, shm_fd, 0);
    if (shm_ptr == MAP_FAILED) {
        cerr << "Failed to map shared memory!" << endl;
        return 1;
    }

    // Open semaphores
    sem_t* sem_write = sem_open(SEM_WRITE, 0);
    sem_t* sem_read = sem_open(SEM_READ, 0);

    if (sem_write == SEM_FAILED || sem_read == SEM_FAILED) {
        cerr << "Failed to open semaphores!" << endl;
        return 1;
    }

    // Consume 5 messages
    for (int i = 0; i < 5; ++i) {
        sem_wait(sem_write); // Wait until full is available

        cout << "[Consumer] Received: " << shm_ptr->message << endl;
        
        sem_post(sem_read); // Signal that space is available
        sleep(1);
    }

    // Cleanup
    sem_close(sem_write);
    sem_close(sem_read);
    munmap(shm_ptr, sizeof(SharedMemory));

    return 0;
}
