#include <iostream>
#include <unistd.h>
#include <cstring>
#include <cstdlib>

using namespace std;

int main() {
    int P1[2]; // Pipe 1 for parent-to-child communication
    int P2[2]; // Pipe 2 for child-to-parent communication
    
    while (true) {
        if (pipe(P1) == -1) { // Create the first pipe (parent to child)
            cerr << "Pipe 1 creation failed!" << endl;
            return 1;
        }
        
        if (pipe(P2) == -1) { // Create the second pipe (child to parent)
            cerr << "Pipe 2 creation failed!" << endl;
            return 1;
        }

        int pid = fork(); // Fork a child process

        if (pid == -1) {
            cerr << "Child Process creation failed!" << endl;
            return 2;
        }

        if (pid == 0) { // Child Process
            close(P1[1]); // Close write-end of P1 in child (we don't write to parent)
            close(P2[0]); // Close read-end of P2 in child (we don't read from parent)

            char str[100];
            // Read from the pipe (parent to child)
            if (read(P1[0], &str, sizeof(str)) == -1) {
                cerr << "Child Process reading from P1 failed!" << endl;
                return 3;
            }
            cout << "Child received from Parent: " << str << endl;

            // Now send a message back to the parent (child to parent)
            const char* buffer = "Hi Mukund!!";
            // Write to the pipe (child to parent)
            if (write(P2[1], buffer, strlen(buffer) + 1) == -1) { // '\0'
                cerr << "Child Process writing to P2 failed!" << endl;
                return 4;
            }

            close(P1[0]); // Close the read-end of P1
            close(P2[1]); // Close the write-end of P2
            return 0;  // Terminate the child process
        } else { // Parent Process
            close(P1[0]); // Close read-end of P1 in parent (we don't read from child)
            close(P2[1]); // Close write-end of P2 in parent (we don't write to child)

            const char* buffer = "Hello Madhav!!";
            // Write to the pipe (parent to child)
            if (write(P1[1], buffer, strlen(buffer) + 1) == -1) {
                cerr << "Parent Process writing to P1 failed!" << endl;
                return 4;
            }

            char str[100];
            // Read from the pipe (child to parent)
            if (read(P2[0], &str, sizeof(str)) == -1) {
                cerr << "Parent Process reading from P2 failed!" << endl;
                return 3;
            }
            cout << "Parent received from Child: " << str << endl;

            close(P1[1]); // Close the write-end of P1
            close(P2[0]); // Close the read-end of P2
        }
        cout<< endl;
        sleep(1); // avoid pipe overflow
    }

    return 0;
}
