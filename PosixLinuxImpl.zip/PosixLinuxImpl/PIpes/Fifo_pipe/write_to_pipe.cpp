#include <iostream>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <cstring>
#include <cstdlib>  
#include <ctime>    // for time

using namespace std;

int main() {
    const char* fifo_pipe = "fifo_write"; // Writer → Reader
    
    // Check if FIFO already exists
    if (mkfifo(fifo_pipe, 0777) == -1) {
        if (errno != EEXIST) {  // Only report error if it's not because the FIFO already exists
            cout << "Pipe couldn't create\n";
            return 1;
        }
    }

    // Seed the random number generator
    srand(time(NULL));

    // Open the FIFO for writing
    int fd_write = open(fifo_pipe, O_WRONLY);
    if (fd_write == -1) {
        cout << "File descriptor couldn't open\n";
        return 1;
    }

    int arr[5];
    for (int i = 0; i < 5; i++) {
        arr[i] = rand() % 20;  // Random numbers between 0 and 19
    }

    // Write data to the FIFO
    if (write(fd_write, &arr, sizeof(int) * 5) != -1) {
        cout << "Write operation Done\n";
    } else {
        cout << "Write operation Failed\n";
        return 2;
    }

    // Close the file descriptor
    close(fd_write);

    return 0;
}
