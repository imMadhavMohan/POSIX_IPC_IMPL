#include <iostream>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <cstring>

using namespace std;

int main() {     
    const char* fifo_pipe = "fifo_write";
    int fd_read = open(fifo_pipe, O_RDONLY);
    
    if(fd_read==-1){
        cout<<"file descriptor couldn't open\n";
        return 1;
    }

    int sum{0};
    int arr[5];

    if(read(fd_read, &arr, sizeof(int)*5)!=-1)
        cout<<"read operation Done\n";
    else{ 
        cout<<"read operation Failed\n";        
        return 2;    
    }

    for(int i=0;i<5;i++)
        sum+=arr[i];

    cout<<"Sum is: "<<sum<<endl;

    close(fd_read);
    return 0;
}
