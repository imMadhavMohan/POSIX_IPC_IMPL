#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

// Signal handler for SIGTERM
void handle_sigterm(int signum) {
    sleep(5);      
    printf("Received SIGTERM (signal %d). Cleaning up...\n", signum);
    exit(0);  
}

int main() {
    // Register SIGTERM handler
    struct sigaction sa;
    sa.sa_handler = handle_sigterm;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0;

    sigaction(SIGTERM, &sa, NULL);

    printf("Process PID: %d\n", getpid());
    printf("Waiting for SIGTERM...\n"); // sudo kill SIGTERM -pid

    // Suspend process until it receives a signal
    pause(); // or while(1)

    printf("This will never print unless pause() returns\n");

    return 0;
}







/*
 The process catches SIGTERM, cleans up, and exits gracefully.
 If no handler is set, SIGTERM simply terminates the process.
*/