#include <iostream>
#include <mqueue.h>
#include <cstring>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#define QUEUE_NAME "/msg_queue"
#define MAX_MSG_SIZE 1024  // Max message size in bytes
#define MAX_MSG 10         // Max number of messages in the queue (this is not directly used here)

using namespace std;

int main() {
    mqd_t mq;  // Correct type for message queue descriptor
    char buffer[MAX_MSG_SIZE];  // Allocate buffer to store messages
    unsigned int priority;  // Priority of the received message
    ssize_t bytes_read;  // Bytes read from the queue

    // Open the message queue in read-only mode
    mq = mq_open(QUEUE_NAME, O_RDONLY);
    if (mq == (mqd_t)-1) {  // Check for error in opening the queue
        perror("mq_open");
        return 1;
    }

    cout << "Waiting to receive messages...\n";

    while (true) {
        // Receive message with priority
        bytes_read = mq_receive(mq, buffer, MAX_MSG_SIZE, &priority); 
        if (bytes_read >= 0) {
            buffer[bytes_read] = '\0';  // Null-terminate the received message
            cout << "Received: " << buffer << " | Priority: " << priority << endl;
        } else {
            perror("mq_receive");
            break;
        }
    }

    // Close the message queue
    if (mq_close(mq) == -1) {
        perror("mq_close");
    }

    // // Unlink the message queue if it's no longer needed (optional)
    // if (mq_unlink(QUEUE_NAME) == -1) {
    //     perror("mq_unlink");
    // }

    return 0;
}









/*
mqd_t mq_open(const char *name, int oflag, mode_t mode, struct mq_attr *attr);

oflag: Flags controlling how the queue is opened.
O_CREAT: Create the message queue if it doesn't exist.
O_EXCL: Fail if the queue exists (used with O_CREAT).
O_RDONLY: Read-only mode.
O_WRONLY: Write-only mode.
O_RDWR: Read/Write mode.

mode: Permissions for the queue (similar to file permissions, e.g., 0666).

attr: Attributes (size, message count) — if NULL, defaults are used.
    struct mq_attr {
        long mq_flags;      // Flags: 0 or O_NONBLOCK
        long mq_maxmsg;     // Maximum number of messages allowed in the queue
        long mq_msgsize;    // Maximum size of each message (in bytes)
        long mq_curmsgs;    // Current number of messages in the queue
    };    
*/