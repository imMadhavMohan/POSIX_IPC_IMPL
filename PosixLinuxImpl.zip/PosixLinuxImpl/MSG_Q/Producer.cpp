#include <iostream>
#include <mqueue.h>
#include <cstring>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#define QUEUE_NAME "/msg_queue"
#define MAX_MSG_SIZE 1024  // Max message size in bytes
#define MAX_MSG 3         // Max number of messages in the queue

using namespace std;

int main() {
    mqd_t mq;  // Use mqd_t as the type for the message queue descriptor
    char message[MAX_MSG_SIZE];  // To store messages
    unsigned int priority;  // Message priority (0-31 as per user input)

    // Set the attributes for the message queue
    struct mq_attr msgq_attr;
    msgq_attr.mq_flags = 0; // Default behavior (blocking)
    msgq_attr.mq_maxmsg = MAX_MSG; // Maximum number of messages in the queue
    msgq_attr.mq_msgsize = MAX_MSG_SIZE; // Maximum size of a message
    msgq_attr.mq_curmsgs = 0; // Current number of messages in the queue (system sets this)

    // Create or open the message queue
    mq = mq_open(QUEUE_NAME, O_CREAT | O_WRONLY, 0666, &msgq_attr);
    if (mq == (mqd_t)-1) {  // Use mqd_t for message queue descriptor, check for failure
        perror("mq_open");
        return 1;
    }

    while (true) {
        cout << "Enter message (or 'exit' to quit): ";
        cin.getline(message, MAX_MSG_SIZE);  // Read message

        if (strcmp(message, "exit") == 0) break;  // Exit condition

        cout << "Enter priority (0 to 10): ";
        cin >> priority;
        cin.ignore();  // Clear the newline character left by cin

        // Send message with priority
        if (mq_send(mq, message, strlen(message) + 1, priority) == -1) {
            perror("mq_send");
        } else {
            cout << "Sent_Msg: " << message << " with priority " << priority << endl<< endl;
        }
    }

    // Close the message queue
    if (mq_close(mq) == -1){
        perror("mq_close");
    }
    return 0;
}
