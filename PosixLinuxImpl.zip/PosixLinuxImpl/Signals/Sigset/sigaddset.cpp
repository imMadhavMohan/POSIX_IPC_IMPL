#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

// Signal handler for SIGUSR1
void handler(int sig) {
    printf("Received SIGUSR1 (signal %d). SIGINT is now blocked!\n", sig);
    sleep(15); // Simulate long signal handling, try 'ctrl+c'
    printf("Exiting SIGUSR1 handler. SIGINT is now unblocked!\n\n");
}

int main() {
    struct sigaction sa;
    sigset_t set;

    // Initialize the signal set and add SIGINT to it
    sigemptyset(&set);
    sigaddset(&set, SIGINT);  // added SIGINT to setmask

    // Configure sigaction
    sa.sa_handler = handler;
    sa.sa_flags = 0;  // No special flags
    sa.sa_mask = set; // Block SIGINT when handling SIGUSR1

    // Register SIGUSR1 with our custom handler
    if (sigaction(SIGUSR1, &sa, NULL) == -1) {
        perror("sigaction failed");
        exit(1);
    }

    if(sigismember(&set, SIGINT)!=-1)
        printf("SIGINT is member of set\n");
    else 
        printf("SIGINT isn't member of set\n");

    printf("Process PID: %d\n", getpid());
    printf("Send SIGUSR1 using: kill -SIGUSR1 %d\n", getpid());
    printf("Try pressing Ctrl+C (SIGINT) during SIGUSR1 handling!\n");

    // Infinite loop to keep the process alive
    while (1) {
        sleep(1);
    }

    return 0;
}
