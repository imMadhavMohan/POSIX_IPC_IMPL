#include <stdio.h>
#include <signal.h>
#include <unistd.h>

void handler(int signo){
    printf("Caught SIGTERM signal %d\n", signo);
}

int main() {
    struct sigaction sa;
    sigset_t new_set, old_set;

    sigemptyset(&new_set);  // Initialize empty set
    
    // Add multiple signals one by one
    sigaddset(&new_set, SIGINT);   // Add Ctrl+C (SIGINT)
    sigaddset(&new_set, SIGTERM);  // Add Termination Signal (SIGTERM)
    sigaddset(&new_set, SIGUSR1);  // Add User-defined Signal 1 (SIGUSR1)

    // configure Sighandler
    sa.sa_handler = handler;
    sa.sa_flags = 0;
    sa.sa_mask = new_set;

    if(sigaction(SIGTERM, &sa, NULL)==-1){
        perror("sigaction:");
        sleep(10);
    }    

    printf("SIGINT/SIGTERM/SIGUSR1 added to the set, but NOT blocked yet!\n");
    sleep(3);  // SIGINT (Ctrl+C) still works here

    sigprocmask(SIG_BLOCK, &new_set, &old_set);  // Now block SIGINT/SIGTERM/SIGUSR1
    printf("SIGINT/SIGTERM/SIGUSR1 is now BLOCKED! Try pressing Ctrl+C...\n");

    printf("SIGINT/SIGTERM/SIGUSR1 is now BLOCKED! Try pressing Ctrl+C/ kill -SIGTERM <%d>/ ...\n", getpid());
    sleep(5);  // SIGINT won't work here

    // sigprocmask(SIG_UNBLOCK, &new_set, &old_set);  // try unblock & test SIGINT/SIGTERM/SIGUSR1

    // Restore original mask
    // sigprocmask(SIG_SETMASK, &old_set, NULL);  
    // printf("SIGINT/SIGTERM/SIGUSR1 is UNBLOCKED now. Press Ctrl+C to exit.\n");

    while (1) {
        printf("Running...\n");
        sleep(1);
    }

    return 0;
}









/*
here "kill -SIGTERM pid & ctrl+c" are unaffective as the we've blocked the mask for the caller process so these interrupts can't affect process execution
if we use "sigprocmask(SIG_UNBLOCK, &new_set, &old_set); " then all will be unblocked
*/