#include <stdio.h>
#include <signal.h>
#include <stdlib.h>
#include <unistd.h>

// Signal handler function
void signal_handler(int signum) {
    printf("Caught signal %d\n", signum);
}

int main() {
    struct sigaction sa;
    sigset_t set;

    // Step 1: Fill signal set with all signals
    sigfillset(&set);

    // Step 2: Remove SIGINT from the blocked signals
    sigdelset(&set, SIGINT);

    // Step 3: Configure sigaction for SIGINT
    sa.sa_handler = signal_handler;  // Set handler
    sa.sa_mask = set;  // Block all signals (except SIGINT)
    sa.sa_flags = 0;  

    // Step 4: Apply sigaction    
    sigaction(SIGINT, &sa, NULL);
    printf("Process PID: %d\n", getpid());
    printf("Try sending SIGINT (Ctrl+C)... Other signals are blocked.\n");

    // Step 5: Check if SIG is in set
    if(sigismember(&set, SIGINT)==0)  
        printf("SIGINT isn't member of set\n");
    else if(sigismember(&set, SIGTERM)!=-1)
        printf("SIGINT is member of set\n");
    
    if(sigismember(&set, SIGTERM)==1)
        printf("SIGTERM is member of set\n");
    else if(sigismember(&set, SIGTERM)!=-1)
        printf("SIGTERM isn't member of set\n");

    // Infinite loop to keep process alive
    while (1) {
        sleep(2);
        printf("Running...\n");
    }

    return 0;
}
