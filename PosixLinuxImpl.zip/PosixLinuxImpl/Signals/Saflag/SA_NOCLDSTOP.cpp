#include <iostream>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

void sigchldHandler(int signum) {
    int status;
    pid_t pid = waitpid(-1, &status, WNOHANG); 
    // waitpid() is a system call used to suspend the calling process until a child process, specified by its process ID (PID), changes state (e.g., terminates or stops)
    if (pid > 0) {
        std::cout << "Child process " << pid << " terminated.\n";
    } else {
        std::cout << "Received SIGCHLD but no child terminated.\n";
    }
}

int main() {
    struct sigaction sa;
    sa.sa_handler = sigchldHandler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_NOCLDSTOP;  // SA_NOCLDSTOP: Ignore SIGCHLD when child stops, try with 0 as well

    sigaction(SIGCHLD, &sa, NULL);

    pid_t pid = fork();
    if (pid == 0) {
        // Child process
        std::cout << "Child process running (PID: " << getpid() << ").\n";
        sleep(2);
        std::cout << "Child stopping itself using SIGSTOP.\n";
        raise(SIGSTOP);  // Stops the child process (normally SIGCHLD would be sent)
        sleep(2);
        std::cout << "Child exiting.\n";
        return 0;
    } else {
        // Parent process
        std::cout << "Parent waiting...\n";
        sleep(5);  // Wait for child actions
        std::cout << "Parent process exiting.\n";
    }

    return 0;
}













/*
pid_t pid = waitpid(-1, &status, WNOHANG); 
returnVal:
    If a child process has changed state, waitpid() returns the PID of the child process whose status is reported. 
    If WNOHANG is specified and no child process has changed state, waitpid() returns 0. 
    If an error occurs, waitpid() returns -1. 

Unlike SIGTSTP, the SIGSTOP signal cannot be caught, blocked, or ignored. When a process receives SIGSTOP, 
it is immediately paused by the operating system.
*/
