#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>

// Signal handler for SIGUSR1
void handle_sigusr1(int sig) {
    printf("Received SIGUSR1 (signal %d). Handling it now...\n", sig);
}

int main() {
    struct sigaction sa, current_sa;
    bool flag = 0;
    // Setup the signal handler
    sa.sa_handler = handle_sigusr1;
    sa.sa_flags = SA_RESETHAND;
    sigemptyset(&sa.sa_mask);

    // Register SIGUSR1 with our handler
    if (sigaction(SIGUSR1, &sa, NULL) == -1) {
        perror("sigaction failed");
        exit(EXIT_FAILURE);
    }

    // Fetch current signal action
    sigaction(SIGUSR1, NULL, &current_sa);
    printf("CurrentHandler: Before signal: Handler = %p, Flags = %d\n", 
           (void*)current_sa.sa_handler, current_sa.sa_flags);
    printf("SAHandler: Before signal: Handler = %p, Flags = %d\n", 
           (void*)sa.sa_handler, sa.sa_flags);

    printf("Process PID: %d\n", getpid());
    printf("Send SIGUSR1 using: kill -SIGUSR1 %d\n", getpid());

    while(true){
        printf("Waiting for SIGUSR1...\n");
        sleep(2);  // Wait for SIGUSR1 to be received
        
        // Fetch current signal action again    
        sigaction(SIGUSR1, NULL, &current_sa);

        if(current_sa.sa_handler == SIG_DFL and flag == 0){    
            flag = 1;
            printf("After signal: Handler = %p, Flags = %d\n", 
                (void*)current_sa.sa_handler, current_sa.sa_flags);
            std::cout << "SIGUSR1 handler reset to default.\n";
        }
    }
    return 0;
}













/*
the current handler check, we're verifying whether SIGUSR1 is still
assigned to our custom handler or if it has been reset to the default action (SIG_DFL).
*/