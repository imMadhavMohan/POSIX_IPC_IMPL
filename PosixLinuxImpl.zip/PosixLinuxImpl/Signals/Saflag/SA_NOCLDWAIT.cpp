#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>

void sigchld_handler(int sig) {
    printf("Parent received SIGCHLD (but child is still a zombie!)\n");
}

int main() {
    struct sigaction sa;
    sa.sa_handler = sigchld_handler;
    sa.sa_flags = 0;  // try: SA_NOCLDWAIT
    sigemptyset(&sa.sa_mask);
    sigaction(SIGCHLD, &sa, NULL);

    pid_t pid = fork();
    if (pid == 0) {
        printf("Child process exiting...\n");
        exit(0);
    } else {
        sleep(3);  // Parent does NOT call wait(), so child remains zombie
        printf("Check for zombie process using: ps aux | grep z\n");
        printf("Parent process (PID: %d), child PID: %d\n", getpid(), pid);
        sleep(5);  // Wait to observe zombie
    }

    return 0;
}
