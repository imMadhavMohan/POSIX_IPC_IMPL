#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <stdlib.h>

// Signal handler for SIGCONT
void handle_sigcont(int signum) {
    printf("Received SIGCONT (signal %d). Resuming operations...\n", signum);
    printf("Process Resumption Done\n");   
}

int main() {
    struct sigaction sa;

    // Clear the sa structure
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART; // Restart interrupted system calls
    sa.sa_handler = handle_sigcont;

    // Set up the SIGCONT handler
    if (sigaction(SIGCONT, &sa, NULL) == -1) { // try: SIGINT: 'ctrl+c'
        perror("Error setting up SIGCONT handler");
        exit(EXIT_FAILURE);
    }

    printf("Process PID: %d\n", getpid());
    fflush(stdout); // Flush the output buffer

    printf("Send SIGSTOP to pause and SIGCONT to resume.\n");    
    raise(SIGSTOP); // or use 'ctrl+z'

    char buffer[50];        
    int bytes = read(STDIN_FILENO, buffer, sizeof(buffer)); // userInput

    if (bytes == -1) {
            perror("read");
        } else {
        printf("You entered: %s\n", buffer);
    }

    while (1) {
        printf("Running...\n");
        sleep(2);
    }

    return 0;
}











/*
SA_RESTART ensures that certain system calls (like read(), write(), recv(), etc.) 
    automatically restart if they are interrupted by a signal.

stop the process using the SIGSTOP signal or manually use "ctrl+z"
resume the process, send the SIGCONT signal (e.g., using the fg command in the terminal

SIGSTOP: is a non-catchable, non-ignorable signal, meaning:
*/