#include <iostream>
#include <signal.h>
#include <unistd.h>
#include <sys/types.h>

void signalHandler(int sig, siginfo_t *info, void *context) {
    if (info != nullptr) {
        pid_t sender_pid = info->si_pid;  // Sender's Process ID
        uid_t sender_uid = info->si_uid;  // Sender's User ID

        std::cout << "[Signal Handler] Received signal: " << sig << "\n";
        std::cout << "[Signal Handler] Sent by process PID: " << sender_pid << "\n";
        std::cout << "[Signal Handler] Sent by user UID: " << sender_uid << "\n";

        // Security check: Allow only signals from root (UID 0)
        if (sender_uid != 0) {
            std::cerr << "[Security Alert] Unauthorized signal sender! Ignoring signal.\n\n";
            return;
        }

        std::cout << "[Signal Handler] Signal accepted and processed.\n"; // root@mohan:~# kill -USR1 <pid>
        std::cout<<'\n'; 
    }
}

int main() {
    struct sigaction sa;
    sa.sa_flags = SA_SIGINFO;  // Use siginfo_t for extra information
    sa.sa_sigaction = signalHandler;
    sigemptyset(&sa.sa_mask);

    // Register signal handler for SIGUSR1
    if (sigaction(SIGUSR1, &sa, nullptr) == -1) {
        perror("sigaction failed");
        return 1;
    }

    std::cout << "[Process Info] Running process PID: " << getpid() << "\n";
    std::cout << "[Process Info] Waiting for SIGUSR1... (Use: kill -USR1 " << getpid() << ")\n\n";

    while (true) {
        pause();  // Wait for signals indefinitely
    }

    return 0;
}
