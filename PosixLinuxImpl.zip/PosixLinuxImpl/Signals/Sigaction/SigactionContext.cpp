#define _GNU_SOURCE // REG_RIP
/*
If you want GNU-specific features (e.g., REG_RIP or ucontext_t extensions),
Uses #define _GNU_SOURCE to enable REG_RIP (for accessing the instruction pointer).
Modifies RIP (Instruction Pointer) to skip the faulting instruction and continue execution.
Access CPU registers in ucontext_t.
*/

#include <iostream>
#include <csignal>
#include <ucontext.h>
#include <unistd.h>

void signalHandler(int signo, siginfo_t *info, void *context) {
    std::cout << "[Signal Handler] Received signal: " << signo << "\n";

    ucontext_t *uc = (ucontext_t *)context;  // Cast context to ucontext_t

#if defined(__x86_64__)  // For x86_64 architecture
    std::cout << "Faulty Instruction at RIP: "<< (void *)uc->uc_mcontext.gregs[REG_RIP] << "\n";

    // Move RIP forward to skip the faulting instruction
    uc->uc_mcontext.gregs[REG_RIP] += 2;  // Skips 2 bytes (adjust as needed)

    std::cout << "Adjusted RIP to: "<< (void *)uc->uc_mcontext.gregs[REG_RIP] << "\n\n";
#endif
}

int main() {
    struct sigaction sa;
    sa.sa_flags = SA_SIGINFO;
    sa.sa_sigaction = signalHandler;
    sigemptyset(&sa.sa_mask);

    // Register SIGSEGV handler
    if (sigaction(SIGSEGV, &sa, nullptr) == -1) {
        perror("sigaction failed");
        return 1;
    }

    std::cout << "[Process Info] Running process PID: " << getpid() << "\n";
    std::cout << "[Process Info] Triggering segmentation fault...\n\n";

    // Intentionally cause segmentation fault
    int *ptr = nullptr;
    *ptr = 42;  // This will generate SIGSEGV

    std::cout << "Execution continued after handling SIGSEGV!\n";

    return 0;
}
