#include <iostream>
#include <signal.h>
#include <cstdlib>
#include <unistd.h>

// Signal handler for SIGSEGV
void segfault_handler(int sig, siginfo_t *info, void *context) {    
    printf("Sent by PID: %d\n", info->si_pid);
    printf("Signal Code: %d\n", info->si_code);
    printf("Caught signal: %d (Segmentation Fault)\n", sig);
    printf("Faulting address: %p\n", info->si_addr);  // Get the invalid memory address
    printf("Signal errCode: %d \n", info->si_errno);
    exit(1);  // Exit after handling
}

int main() {
    struct sigaction sa;
    sa.sa_flags = SA_SIGINFO;  // Use sa_sigaction instead of sa_handler
    sa.sa_sigaction = segfault_handler;

    sigaction(SIGSEGV, &sa, NULL);  // Register signal handler for SIGSEGV

    printf("Causing segmentation fault...\n");
    int *ptr ;  // Null pointer or keep uninitialized 
    *ptr = 42;  // Writing to NULL causes SIGSEGV
    
    return 0;
}
