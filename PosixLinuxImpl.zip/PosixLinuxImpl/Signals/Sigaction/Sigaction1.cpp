#include <signal.h>
#include <stdio.h>
#include <unistd.h>

// Simple signal handler
void handler(int sig) {
    printf("Received signal: %d\n", sig);
}

int main() {
    struct sigaction sa;
    sa.sa_handler = handler;  // Assigning handler function
    sa.sa_flags = 0;          // No special flags

    sigaction(SIGINT, &sa, NULL);  // Handle SIGINT (Ctrl+C)

    printf("Press Ctrl+C to send SIGINT\n");
    while (1) sleep(1);  // Keep running

    return 0;
}
