#include <signal.h>
#include <stdio.h>
#include <unistd.h>

// Advanced signal handler
void handler(int sig, siginfo_t *info, void *ucontext) {
    printf("Received signal: %d\n", sig);
    printf("Sent by PID: %d\n", info->si_pid);
    printf("Signal Code: %d\n", info->si_code);
}

int main() {
    struct sigaction sa;
    sa.sa_sigaction = handler;  // Assigning advanced handler
    sa.sa_flags = SA_SIGINFO;   // Enable siginfo_t details

    sigaction(SIGINT, &sa, NULL);  // Handle SIGINT (Ctrl+C)

    printf("Press Ctrl+C to send SIGINT\n");
    while (1) sleep(1);  // Keep running

    return 0;
}
