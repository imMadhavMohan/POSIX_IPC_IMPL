#include <stdio.h>
#include <signal.h>
#include <unistd.h>

void handler(int signum) {
    printf("Caught signal: %d\n", signum);
}

int main() {
    sigset_t set;

    sigemptyset(&set);         // Initialize empty signal set
    sigaddset(&set, SIGINT);   // Add SIGINT (Ctrl+C)

    // Block SIGINT
    sigprocmask(SIG_BLOCK, &set, NULL);
    printf("SIGINT is blocked. Press Ctrl+C... Nothing will happen!\n");
    sleep(15);

    // Unblock SIGINT
    sigprocmask(SIG_UNBLOCK, &set, NULL);
    printf("SIGINT is unblocked. Now Ctrl+C will work.\n");

    return 0;
}
