#include <signal.h>
#include <iostream>
#include <unistd.h>

using namespace std;

// Signal Handler Function
void handle_signal(int signal) {
    printf("Received Signal: %d\n", signal);        
}

int main() {
    // Register signal handler for SIGINT (Ctrl + C)
    signal(SIGINT, handle_signal);

    printf("Running... Press Ctrl+C to send SIGINT.\n");
    while (1) {
        sleep(1);  // Keep the process running
    }
    return 0;
}
