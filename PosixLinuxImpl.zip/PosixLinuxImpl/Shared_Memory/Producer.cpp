#include <iostream>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstring>
#include <semaphore.h>

#define SHM_NAME "/myshm"
#define SEM_NAME "/mysem"
#define SHM_SIZE 1024

using namespace std;

int main() {
    // Create or open shared memory object
    int fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    if (fd == -1) {
        cerr << "Error: Failed to open shared memory" << endl;
        return 1;
    }

    ftruncate(fd, SHM_SIZE);
    char* ptr = (char*) mmap(NULL, SHM_SIZE, PROT_WRITE, MAP_SHARED, fd, 0);
    if (ptr == MAP_FAILED) {
        cerr << "Error: Failed to map memory" << endl;
        return 1;
    }

    // Create or open semaphore
    sem_t* sem = sem_open(SEM_NAME, O_CREAT, 0666, 1);
    if (sem == SEM_FAILED) {
        cerr << "Error: Failed to open semaphore" << endl;
        return 1;
    }

    // Write to shared memory
    const char* message = "Hello from Thread-Safe Producer!";

    if(sem_wait(sem) == -1) // Lock the semaphore before writing
        cout<<"Error: Sem_Wait\n";

    strcpy(ptr, message);
    cout << "Producer wrote: " << message << endl;

    if(sem_post(sem) == -1) // unlock the semaphore after writing
        cout<<"Error: Sem_Post\n"; 

    // Cleanup
    if(munmap(ptr, SHM_SIZE) == -1)
        cout<<"Error: munmap\n";

    if(close(fd) == -1)        
        cout<<"Error: close\n";

    if(sem_close(sem) == -1)
        cout<<"Error: sem_close\n";

    return 0;
}
