#include <iostream>
#include <sys/mman.h>  // shm_open/mmap
#include <fcntl.h>
#include <unistd.h>
#include <cstring>
#include <semaphore.h>  // sem_open/close

#define SHM_NAME "/myshm"
#define SEM_NAME "/mysem"
#define SHM_SIZE 1024

using namespace std;

int main() {
    // Open shared memory object
    int fd = shm_open(SHM_NAME, O_RDONLY, 0666);
    if (fd == -1) {
        cerr << "Error: Failed to open shared memory" << endl;
        return 1;
    }

    char* ptr = (char*) mmap(NULL, SHM_SIZE, PROT_READ, MAP_PRIVATE, fd, 0); // void*->char*
    if (ptr == MAP_FAILED) {
        cerr << "Error: Failed to map memory" << endl;
        return 1;
    }

    // Open semaphore
    sem_t* sem = sem_open(SEM_NAME, 0);
    if (sem == SEM_FAILED) {
        cout << "Error: Failed to open semaphore" << endl;
        return 1;
    }

    // Read from shared memory
    if(sem_wait(sem) == -1) // Lock the semaphore before reading
        cout<<"Error: Sem_Wait\n";

    cout << "Consumer read: " << ptr << endl;

    if(sem_post(sem) == -1) // Unlock the semaphore after reading
        cout<<"Error: Sem_Post\n";

    // Cleanup
    if(munmap(ptr, SHM_SIZE) == -1)
        cout<<"Error: munmap\n";

    if(close(fd) == -1)        
        cout<<"Error: close\n";

    if(sem_close(sem) == -1)
        cout<<"Error: sem_close\n";

    // if(shm_unlink(SHM_NAME) == -1) // check: "ls -l /dev/shm"
    //     cout<<"Error: shm_unlink\n";

    if(sem_unlink(SEM_NAME) == -1)
        cout<<"Error: sem_unlink\n";

    return 0;
}

















/*
If you're not using "shm_unlink(SHM_NAME)"" it'll persist until restart  is done,
No Persistance after reboot:
If you reboot the system, all shared memory objects created with shm_open() are automatically cleaned up.
Reason: POSIX shared memory is managed via a virtual file system (usually /dev/shm), which doesn't survive a reboot.
*/






/*
g++ -o producer producer.cpp -lrt -lpthread
g++ -o consumer consumer.cpp -lrt -lpthread
-lrt: link realtime library

void* mmap(void *addr, size_t length, int prot, int flags, int fd, off_t offset);

void *addr:
    Starting address where the mapping should begin. Usually NULL to let the kernel choose.
size_t size:
    size(byte)
int Prot_flag: Protection flag for memory
    PROT_READ	Pages can be read.(Only read is allowed. Writing will cause a segmentation fault.)
    PROT_WRITE	Pages can be written.(Allows writing but not reading.)
    PROT_EXEC	Pages can be executed.
    PROT_NONE	No access.
int flags:
    MAP_SHARED	Changes are visible to other processes mapping the same file.
    MAP_PRIVATE	Changes are not visible to other processes(as they're temporary or for experiment).
    MAP_ANONYMOUS	No file is associated; creates an anonymous memory region.
    MAP_FIXED	Forces mapping at the given address.
Return Value: (void*)ptr to mapped memory region or (void*)-1 = MAP_FAILED
Offset:
    Start position (in bytes) from which mapping begins, 0: from start
    offset makes it possible to map a partial file & Helps avoid loading the entire file into memory, saving resources.
    offset parameter in mmap() must be a multiple of the system's page size (typically 4096 bytes on Linux($getconf PAGESIZE)
    void* map = mmap(NULL, 4096, PROT_READ, MAP_PRIVATE, fd, 0);
    // Valid: Offset is 0 (page-aligned)

    void* map = mmap(NULL, 4096, PROT_READ, MAP_PRIVATE, fd, 8192);
    // Valid: Offset is 8192 (multiple of 4096)

    void* map = mmap(NULL, 4096, PROT_READ, MAP_PRIVATE, fd, 1000);
    // Invalid: Offset is 1000 (NOT a multiple of 4096), returning MAP_FAILED.
*/