#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

// Signal handler for SIGCHLD
void handle_sigchld(int sig) {    
    sleep(15);
    while (waitpid(-1, NULL, WNOHANG) > 0) {
        printf("Zombie process reaped!\n");
    }
}

int main() {
    struct sigaction sa;
    sa.sa_handler = handle_sigchld;   // Set handler for SIGCHLD
    sa.sa_flags = SA_RESTART | SA_NOCLDSTOP;  // Restart syscalls, ignore stopped children
    sigemptyset(&sa.sa_mask);  // No additional signals blocked

    // Register SIGCHLD handler
    if (sigaction(SIGCHLD, &sa, NULL) == -1) {
        perror("sigaction failed");
        exit(1);
    }

    pid_t pid = fork();

    if (pid < 0) {
        perror("fork failed");
        exit(1);
    }

    if (pid == 0) {
        // Child process
        printf("Child process (PID: %d) exiting...\n", getpid());
        exit(0);  // Child exits, becoming a zombie temporarily
    } else {
        // Parent process
        printf("Parent process (PID: %d), child PID: %d\n", getpid(), pid);
        
        // Sleep to allow time to observe the zombie
        sleep(10);

        // Check child status using `ps`
        printf("Run 'ps aux | grep %d' to check if zombie exists\n", pid);

        // Sleep to observe that SIGCHLD has handled the zombie
        sleep(5);

        printf("Exiting parent process.\n");
    }

    return 0;
}










/*
check zombie proces: ps aux | grep Z
A zombie process occurs when a child process finishes but the parent process has not called wait() to read its status.
It is not an active process and does not consume CPU or memory but it can still occupy an entry in the process table.
Too many zombie processes can cause issues by filling up the process table, limiting the creation of new processes.


Kernel(init process): init is the first process started by the Linux kernel when the system boots up.
 It has PID 1 and is responsible for starting all other processes and managing orphaned ones.


*/ 
